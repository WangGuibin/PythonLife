from  tkinter import *
from  easygui import *
import pickle
# class App(Frame):
#     def __init__(self,master=None):
#         Frame.__init__(self,master)
#         self.pack()
#         self.setupUI()
#
#     def setupUI(self):
#         self.helloLabel = Label(self,text="你好啊!世界",bg='red',fg="green")
#         self.helloLabel.pack(side=TOP)
#         self.quitBtn = Button(self,text="退出(exit(0))",fg='orange',command=self.removeFromSupView)
#         self.quitBtn.pack(side=LEFT)
#         self.rightLabel = Label(self,text="我就是右边的文本了",bg="black",fg="white")
#         self.rightLabel.pack(side=TOP)
#         self.pack(padx=100,pady=100)
#
#
#
#     def removeFromSupView(self):
#             index = indexbox("需要退出这个窗口吗?","弹窗",["取消","确认"])
#             if index == 1:
#                     self.quit()
#
# app = App()
# app.master.title("Demo system GUI")
# app.mainloop()

### 按钮
# def buttonClick():
#         print("按钮被点击了"+str(var.get()))
#
#
#
# root = Tk()
# button = Button(root,text="按钮",fg="red",font=("KaiTi",20,'bold'),height= 50,width= 25,command=buttonClick)
# button.pack()
# e = StringVar()
# entry = Entry(root,textvariable=e)
# e.set('请输入...')
# entry.pack()

# for index in range(0,16):
#         Button(root,text=str(index+1)).grid(row=int(index/4),column=index%4)

# var = IntVar()
# R1 = Radiobutton(root, text="Option 1", variable=var, value=1,command=buttonClick)
# R1.pack( anchor = W )
#
# root.mainloop()

#### 颜色板
# with open("./colors.pkl",'rb') as f:
#         colors = pickle.load(f)
#         root = Tk()
#         i = 0
#         colcut = 5
#         for color in colors.split('\n'):
#             sp = color.split(' ')
#             try:
#                 Label(text=color, bg=sp[1]).grid(row=int(i / colcut), column=i % colcut, sticky=W + E + N + S)
#             except:
#                 print('err', color)
#                 Label(text='ERR' + color).grid(row=int(i / colcut), column=i % colcut, sticky=W + E + N + S)
#             i += 1
#         root.mainloop()


################
### 菜单界面

def hello():
        msgbox("hello world!")
top=Tk()
top.wm_title("菜单")
top.geometry("400x300+300+100")

# 创建一个菜单项，类似于导航栏
menubar=Menu(top)

# 创建菜单项
fmenu1=Menu(top)
for item in ['新建','打开','保存','另存为']:
    # 如果该菜单时顶层菜单的一个菜单项，则它添加的是下拉菜单的菜单项。
    fmenu1.add_command(label=item,command=hello)


fmenu2=Menu(top)
for item in ['复制','粘贴','剪切']:
    fmenu2.add_command(label=item,command=hello)

fmenu3=Menu(top)
for item in ['默认视图','新式视图']:
    fmenu3.add_command(label=item,command=hello)

fmenu4=Menu(top)
for item in ["版权信息","其他说明"]:
    fmenu4.add_command(label=item,command=hello)

# add_cascade 的一个很重要的属性就是 menu 属性，它指明了要把那个菜单级联到该菜单项上，
# 当然，还必不可少的就是 label 属性，用于指定该菜单项的名称
menubar.add_cascade(label="文件",menu=fmenu1)
menubar.add_cascade(label="编辑",menu=fmenu2)
menubar.add_cascade(label="视图",menu=fmenu3)
menubar.add_cascade(label="关于",menu=fmenu4)

# 最后可以用窗口的 menu 属性指定我们使用哪一个作为它的顶层菜单
top['menu']=menubar
top.mainloop()