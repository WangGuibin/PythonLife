from pyecharts import Bar,Line

bar = Bar("我是标题","我是副标题啊")
bar.use_theme("dark")
bar.add("食物",["油条","包子","豆浆","烧麦","炒粉","肠粉"],[1.5,1.0,2.0,2.0,4.0,5.0],is_stack=True)

line = Line('折线图',"折线图副标题")
line.add("食物",["油条","包子","豆浆","烧麦","炒粉","肠粉"],[1.5,1.0,2.0,2.0,4.0,5.0],is_stack=True)

line.render("line.html")
bar.render("bar.html")