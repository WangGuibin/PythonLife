# -*- coding: utf-8 -*-
import random
import hashlib
import requests


class youdao_api():

    def __init__(self):
        self.appKey = '62336c715a8836aa'
        self.secretKey = 'XdDF65gMthvPIqoiYiSQga8Gj2CNRLkW'
        self.base_url = 'http://openapi.youdao.com/api'
        self.fromLang = 'en'
        self.toLang = 'zh-CH'
        self.salt = random.randint(1, 65536)
        self.lang_dict = {'中文': 0, '日文': 1, '英文': 2, '韩文': 3, '法文': 4, '俄文': 5, '葡萄牙文': 6, '西班牙文': 7, '越南文': 8, }
        print('支持的语言有：中文，日文， 英文， 韩文， 法文， 俄文， 葡萄牙文， 西班牙文， 越南文')

    def params_make(self):
        sign = '%s%s%s%s' % (self.appKey, self.q, str(self.salt), self.secretKey)
        m1 = hashlib.md5()
        m1.update(sign.encode())
        sign = m1.hexdigest()
        params = {
            'appKey': self.appKey,
            'q': self.q,
            'from': self.fromLang,
            'to': self.toLang,
            'salt': self.salt,
            'sign': sign
        }
        return params

    def get_result(self, params):
        url = self.base_url
        result = requests.get(url, params).json()
        return '翻译结果：' + str(result.get('translation', 'None'))

    def input_words(self):
        try:
            text = input('请输入需要翻译的文本：')
            return text
        except:
            print('error:input_words')
            self.input_words()

    def from_lang(self):
        print('中文=0，日文=1， 英文=2， 韩文=3， 法文=4， 俄文=5， 葡萄牙文=6， 西班牙文=7， 越南文=8')
        try:
            lang = int(input('请输入要翻译的语言代码：'))
            if lang in list(self.lang_dict.values()):
                return lang
            else:
                print('请输入正确的数字')
                self.from_lang()
        except:
            print('请输入正确的数字')
            self.from_lang()

    # def to_lang(self):
    #     print('中文=0，日文=1， 英文=2， 韩文=3， 法文=4， 俄文=5， 葡萄牙文=6， 西班牙文=7， 越南文=8')
    #     try:
    #         lang = int(input('请输入要翻译成的语言代码：'))
    #         if lang in list(self.lang_dict.keys()):
    #             return lang
    #         else:
    #             print('请输入正确的数字')
    #             self.to_lang()
    #     except:
    #         print('请输入正确的数字')
    #         self.to_lang()

    def run(self):
        self.fromLang = self.from_lang()
        #self.toLang = 'en'
        self.q = self.input_words()
        params = self.params_make()
        result = self.get_result(params)
        print(result)


if __name__ == '__main__':
    translator = youdao_api()
    translator.run()
