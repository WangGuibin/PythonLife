import matplotlib.pyplot as plt
from wordcloud import WordCloud
import jieba
from  pyecharts import WordCloud
from collections import Counter

text_from_file_with_path = open('./word.txt').read()

wordlist_after_jieba = jieba.cut(text_from_file_with_path, cut_all=True)
wl_space_split = " ".join(wordlist_after_jieba)

### 方案一
# my_wordcloud = WordCloud(background_color = 'white',    # 设置背景颜色
#                 font_path = '/Library/Fonts/Songti.ttc',# 设置字体格式，如不设置显示不了中文
#                 max_font_size = 50,            # 设置字体最大值
#                 random_state = 10,            # 设置有多少种随机生成状态，即有多少种配色方案
#                 ).generate(wl_space_split)
#
# plt.imshow(my_wordcloud)
# plt.axis("off")
# plt.show()

### 方案二 用pyecharts

wordlist = wl_space_split.split(" ",10000)
counts = Counter(wordlist)
times = counts.most_common(100)
array = []
values = []
for list in  times:
        array.append(list[0])
        values.append(list[1])

wordcloud = WordCloud(width=1920, height=1080)
wordcloud.add("", array,values, word_size_range=[20, 200])
wordcloud.render("wordcloud.html")