from  easygui import *
# from  PIL import Image

# index = msgbox("你好,世界!","温馨提示","好的!",image="233.png")
# print(index)

# index = multpasswordbox("请输入账号密码","登录",["账号","密码"],["",])
# print(index)

######### 小游戏
# index = choicebox("选一个吧","选择题",["A","B","C","D"],0)
# print(index)
# if index == "A":
#         ok = msgbox("这是一个A选项,恭喜你是多选题","答案")
#         if ok == "OK":
#                item = multchoicebox("多选或者不选","多选题",["一个","两个","三个","以上都不对","以上都对"])
#                print(item)
# elif index == "B":
#        ok = msgbox("这是一个B选项,需要登录", "答案")
#        if ok == "OK":
#                item = multpasswordbox("请输入账号密码", "登录", ["账号", "密码"], ["", ])
#                print(item)
# elif index == "C":
#        res = msgbox("这是一个C选项,显示文本", "答案")
#        if res == "OK":
#              textbox("展示文本","文本框","大江东去,浪淘尽,千古风流人物,故垒西边,人道是,三国周郎赤壁,乱石穿空,惊涛拍岸,卷起千堆雪,遥想公瑾当年,小乔初嫁了,雄姿英发...兔子撒鹰,狮子搏兔")
# else:
#        haha = msgbox("这是一个D选项", "答案")
#        if haha == "OK":
#                item = buttonbox("小提示弹窗","提示",["第一个","第二个","第三个"],"233.png")
#                print(item)

#            'EgStore',
#            'eg_version',
#            'egversion',
#            'abouteasygui',
#            'egdemo',

# exceptionbox("啥也没有","报错?")
egdemo()