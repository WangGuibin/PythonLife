from  pyecharts import Radar

schema = [
    ("房租",2000),("吃饭",2000),("交通",500),("应酬",1500),("游玩",1000),("知识付费",1000)
]

v1 = [[1600,1700,340,800,550,500]]
v2 = [[1700,1800,440,1000,150,200]]

radar = Radar()
radar.config(schema)
radar.add("预算分配", v1, is_splitline=True, is_axisline_show=True)
radar.add("实际开销", v2, label_color=["#4e79a7"], is_area_show=False,
          legend_selectedmode='single')
radar.render("radar.html")