# 排序算法了解下

## 简单冒泡排序
def bubbleSort(arr):
        for i in range(0,len(arr)-1):
                for j in range(0,len(arr) - i - 1):
                         if arr[j] > arr[j+1]:
                                temp = arr[j]
                                arr[j] = arr[j+1]
                                arr[j+1] = temp

## 升级版的冒泡
def bubbleSortPlus(arr):
        left = 0
        right = len(arr) - 1
        while left < right:
                for i in range(left,right):
                    if arr[i] > arr[i+1]:
                        temp = arr[i]
                        arr[i] = arr[i+1]
                        arr[i+1] = temp
                right-=1
                j = right
                while j >= left:
                        if arr[j+1] < arr[j]:
                                temp = arr[j]
                                arr[j] = arr[j+1]
                                arr[j+1] = temp
                        j -= 1
                left+=1


#堆排序
# def createHeap(arr,i,n):
#         while i > 0:
#                 left = 2*i + 1
#                 right = 2*i+2
#                 j = (left if arr[left] > arr[right] else right) if right < n else left
#                 if arr[j] > arr[i]:
#                             temp = arr[i]
#                             arr[j] = arr[i]
#                             arr[i] = temp
#
#
#
# def heapSort(arr):
#         n = len(array)
#         createHeap(array,int(n/2) -1 ,n)
#         j = n -1
#         while j < 0:
#                 temp = array[0]
#                 array[0] = array[j]
#                 array[j] = temp
#                 i = int(j/2) - 1
#                 createHeap(array,i,j)
#                 j-=1

#插入排序
# def insertSort(arr):
#         n = len(arr)
#         temp = 0
#         for i in range(1,n):
#                 j = i-1
#                 if arr[i] < arr[j]:
#                             temp = arr[i]
#                             arr[i] = arr[j]
#                             while temp < arr[j-1]:
#                                     arr[j] = arr[j-1]
#                                     j-=1
#                             arr[j] = temp




array = [12,3,46,67,11,32,10,9,4,5,7,8]
# bubbleSort(array)
# bubbleSortPlus(array)
# heapSort(array)
# insertSort(array)

print(array)