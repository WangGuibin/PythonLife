import scrapy
from bs4 import BeautifulSoup
import json
import csv

class Dongtan(scrapy.Spider):
        name = 'dongtan'
        allow_domains = ['oschina.net',]

        def start_requests(self):
                url = 'https://www.oschina.net/tweets'
                headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'zh-CN, zh;q=0.9, en;q=0.8',
                'Cache-Control': 'max-age=0',
                'Connection': 'keep - alive',
                'Cookie': 'aliyungf_tc = AQAAAFq / xnfCMAMAF7IPt5qZmVmtrfPA;_user_behavior_ = ca2d4f7e-c476-44\
                eb-8030-1\
                a2ab26d3ef1;\
                Hm_lvt_a411c4d1664dd70048ee98afe7b28f0b=1536282198;\
                Hm_lpvt_a411c4d1664dd70048ee98afe7b28f0b=1536283033',
                'Host': 'www.oschina.net',
                'Referer': 'https://my.oschina.net/xxiaobian/blog/1980119',
                'Upgrade-Insecure -Requests' : '1',
                'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
                }
                yield scrapy.Request(url,headers=headers)

        def parse(self, response):
                html = response.text
                bs = BeautifulSoup(html)
                alist = bs.find_all('a',attrs={'class':'user __user'})
                imgs = response.xpath('//div[@class="osc-avatar small-portrait _35x35 avatar"]/img/@src').extract()
                divs = response.xpath('//div[@class="extra text"]/text()').extract()
                out = open('Dontan_csv.csv', 'a', newline='')
                csv_writer = csv.writer(out,dialect='excel')
                csv_writer.writerow(['用户名','用户链接','动弹'])
                for index,a in enumerate(alist):
                        username = a.string
                        userlink = a.get('href')
                        # img = imgs[index]
                        text = divs[index]
                        csv_writer.writerow([username,userlink,text])

