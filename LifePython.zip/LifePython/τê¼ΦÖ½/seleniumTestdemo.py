from  selenium import  webdriver
# from  selenium.webdriver.common.keys import Keys
from  selenium.webdriver.support.ui import WebDriverWait
from  selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import re

web = webdriver.Chrome()
wait = WebDriverWait(web, 5, 0.5)


def search_keyword(keyword="美食"):
    web.get('https://www.taobao.com/')
    inputbox = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR,'#q')))
    button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR,'#J_TSearchForm > div.search-button > button')))
    inputbox.clear()
    inputbox.send_keys(keyword)
    button.click()

    totalPages = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#mainsrp-pager > div > div > div > div.total'))).text
    totalPages = re.search('(\d+)', totalPages).group(1)
    return totalPages



# print(search_keyword())