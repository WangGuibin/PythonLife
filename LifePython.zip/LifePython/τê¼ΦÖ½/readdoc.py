from goose3 import  Goose
from  goose3.text import StopWordsChinese

url = 'https://item.btime.com/36a0f17i0489keqltn35q96p4lr?from=haozcxw'
g =  Goose({'stopwords_class': StopWordsChinese})
article = g.extract(url)
print(article.title)
print(article.meta_description)
print(article.cleaned_text)





