import urllib.request
import re
from bs4 import BeautifulSoup
import sys
import time

# 解决中文字符不能正确显示的问题
# reload(sys)
# sys.setdefaultencoding('utf-8')
# =======================获取该链接的总页数====================================

def get_max_page(url):
    request = urllib.request.urlopen(url)
    html_content = request.read()
    request.close()
    soup_max_page = BeautifulSoup(html_content, "lxml")
    a_max_page = soup_max_page.find('a', text=re.compile(u"尾页"))
    str_link = str(a_max_page).split("=")[-1]
    page = str_link.split("\"")[0]
    max_page = int(page)
    return max_page
def get_content(url_html, max_page, regex):
    count = 1   # 定义一个计数
    # 将正则表达式编译为一个pattern实例
    regex_pattern = re.compile(regex, re.IGNORECASE)
# ========================遍历每页页面=========================================
    for index in range(1, max_page+1):
        email_count = 0
        url_page = url_html + str(index)
        request_page = urllib.request.urlopen(url_page)
        html_content_page = request_page.read()
        request_page.close()
        soup = BeautifulSoup(html_content_page, "lxml")
        cc_table = soup.find_all(text=regex_pattern)
        for email in cc_table:
            email_out = regex_pattern.search(email).group()
            file_email.write(str(count)+" : "+email_out+"\n")
            email_count += 1
            count += 1
        print("========已完成第%d页的提取========" % (index))
        print("该页共搜集%d个邮箱\n" % (email_count))
    print("该链接共获取到 %d 个邮箱\n" % (count-1))
if __name__ == '__main__':
    # 程序开始时间
    start_time = time.time()
    # 在文件中以追加的方式写入数据
    file_email = open("data.txt", "w")
    # 定义email的正则表达式
    regex = r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}\b"
    # 定义链接的首页，便于获取总页数
    url = "http://tieba.baidu.com/p/950187586"
    max_page = get_max_page(url)
    # 取得总页数的时间
    mid_time = time.time()
    print("\n========取得页数成功，该帖子共有：%d 页========\n" % (max_page))
    print("用时：%f s\n" % (mid_time-start_time))
    # 定义需要爬的链接
    url_html = "http://tieba.baidu.com/p/3801842535?pn="
    get_content(url_html, max_page, regex)
    file_email.close()
    # 程序结束的时间
    end_time = time.time()
    # 打印出程序运行时间
    print("\n========程序已完成========")
    print("用时：: %f s" % (end_time-start_time))