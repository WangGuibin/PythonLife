import urllib.request
from urllib.request import Request
import os
import random
from bs4 import  BeautifulSoup


# 获取内容
def url_open(url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1'

        }
        req = Request(url,headers=headers)
        data = urllib.request.urlopen(req)
        html = data.read()
        return html

# 读取图片
def getContent():
        url = 'https://www.dosmono.com/'
        html = url_open(url)
        soup = BeautifulSoup(html,'lxml')
        lists = soup.select('img')
        os.mkdir('/Users/wangguibin/Desktop/dosImages')
        os.chdir('/Users/wangguibin/Desktop/dosImages')
        for tag in lists:
                filename = 'https://www.dosmono.com/'+tag['src']
                data = url_open(filename)
                print(filename)
                with open(filename.split('/')[-1],'wb') as  f:
                        f.write(data)

getContent()
