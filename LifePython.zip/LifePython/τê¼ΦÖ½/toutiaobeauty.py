import requests,os

root_dir = "."
root_path = os.path.abspath(root_dir)

kw = ''


while True:
    kw = input("请输入你要搜索的图片(停止爬虫请扣1),请输入: ")
    if kw == '1':
       print("您下载的图片已经保存在"+root_path + ",请注意查收!")
        break
    for page in range(0,1000,20):
        url = 'https://www.toutiao.com/search_content/?offset='+str(page)+'&format=json&keyword=%s&autoload=true&count=20&cur_tab=1&from=search_tab&from=gallery' % kw
        result = requests.get(url)
        data = result.json()['data']
        # print(data)
        if not data:
            print('图片'+kw+'下载完毕,请换个关键词继续..')
            break
        n = 1 #记录文章数
        for article in data:
            if 'title' in article:
                title = article['title']
                with open('word.txt', mode='a+', encoding='utf-8') as f:
                        f.write(title+'\n')
                print(article)
                try:
                    if title not in os.listdir(root_dir):
                        os.mkdir(title)
                except OSError as error:
                    print('文件名出错,创建目录失败,重新创建一个随机名字...')
                    title = kw + '文件名出错' + str(page)
                    if title not in os.listdir(root_dir):
                        os.mkdir(title)
                k = 1 # 记录下载图片数
                path = os.path.join(root_path,title)
                os.chdir(path) # 转进图片目录
                for image in article['image_list']:
                    image_url = image['url'].replace('list','large')
                    atlas = requests.get("http:"+image_url).content
                    with open(str(k)+'.png','wb') as f:
                        f.write(atlas)
                    print('下载的第%d个文章%d个图片完成' % (page+n,k))
                    k += 1
                n += 1
                os.chdir(root_path) #转出图片目录

