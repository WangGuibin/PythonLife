import scrapy
from juejin.items import JuejinItem
from  bs4 import  BeautifulSoup
import json

class JuejinSpider(scrapy.Spider):
            name = 'juejin'
            allow_domains = ['juejin.im']
            headers = {
                'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
            }

            def start_requests(self):
                url = 'https://juejin.im/welcome/ios'
                yield scrapy.Request(url,headers=self.headers)

            def parse(self, response):
                html = response.text
                bs = BeautifulSoup(html)

                #获取时间信息
                timelist = []
                time = bs.find_all('li',attrs={'class':'item tag'})
                for li in time:
                       text = li.previous_sibling.string
                       timelist.append(text)

                # 获取作者名字
                name = bs.find_all('li',attrs={'class':'item username clickable'})
                namelist = []
                for i in name:
                    for div in i.children:
                         text = div.contents[1].contents[0]
                         namelist.append(text)

                # 获取文章链接和标题
                a = bs.find_all('a',attrs={'class':'title','target':'_blank'})
                listItem = []
                for index,item in enumerate(a):
                     content = JuejinItem()
                     content['link'] = 'https://juejin.im' + item.get('href')
                     content['title'] = item.string
                     content['name'] = namelist[index]
                     # content['time'] = timelist[index]
                     listItem.append(content)
                with open('juejin.json', 'w') as f:
                             json.dump([dict(x) for x in listItem],f,ensure_ascii=False,indent=4)








