#!/usr/bin/python
# -*- coding:utf-8 -*-

from urllib import *
import datetime
import base64
import hmac
import hashlib
import json
import requests

def get_current_date():
    date = datetime.datetime.strftime(datetime.datetime.utcnow(), "%a, %d %b %Y %H:%M:%S GMT")
    return date

def to_md5_base64(strBody):
    hash = hashlib.md5()
    hash.update(body)
    return hash.digest().encode('base64').strip()

def to_sha1_base64(stringToSign, secret):
    hmacsha1 = hmac.new(secret, stringToSign, hashlib.sha1)
    return base64.b64encode(hmacsha1.digest())

ak_id = 'LTAI47MSPbpBwhec'
ak_secret = 'yYdtP4DLHeiyuQ6jTBVwiAJRKiIO6S'

options = {
    'url': 'https://dtplus-cn-shanghai.data.aliyuncs.com/image/tag',
    'method': 'POST',
    'body': json.dumps({"image_url": "https://upload.wikimedia.org/wikipedia/commons/1/12/Broadway_and_Times_Square_by_night.jpg","type" : 1}, separators=(',', ':')),
    'headers': {
        'accept': 'application/json',
        'content-type': 'application/json',
        'date':  get_current_date(),
        'authorization': ''
    }
}

# options = {
#     'url': '<请求的url>',
#     'method': 'GET',
#     'headers': {
#         'accept': 'application/json',
#         'content-type': 'application/json',
#         'date': get_current_date(),  # 'Sat, 07 May 2016 08:19:52 GMT',  # get_current_date(),
#         'authorization': ''
#     }
# }


body = ''
if 'body' in options:
    body = options['body']
print(body)

bodymd5 = ''
if not body == '':
    body = body.encode('utf-8')
    bodymd5 = to_md5_base64(body)
print(bodymd5)

urlPath = "https://dtplus-cn-shanghai.data.aliyuncs.com/image/tag"

stringToSign = options['method'] + '\n' + options['headers']['accept'] + '\n' + bodymd5 + '\n' + options['headers']['content-type'] + '\n' + options['headers']['date'] + '\n' + urlPath

signature = to_sha1_base64(stringToSign, ak_secret)

print(stringToSign)

authHeader = 'Dataplus ' + ak_id + ':' + signature
options['headers']['authorization'] = authHeader

print(authHeader)

request = None
method = options['method']
url = options['url']

print(method)
print(url)



for key, value in options['headers'].items():
    request.add_header(key, value)

conn  = requests.request(url,body=body,headers= options['headers'])
response = conn.read()
print(response)

