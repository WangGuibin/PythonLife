from django.contrib import admin
from TestModel.models import Test,Contact,Tag

class TagInline(admin.TabularInline):
        model = Tag


class ContactAdmin(admin.ModelAdmin):
            list_display = ('name', 'age', 'email')  # list
            search_fields = ('name',) #搜索
            inlines = [TagInline,]  # Inline

        #fields = ('name','email') #Contact模型只显示这两项
            fieldsets = (
                ['Main', {
                    'fields': ('name', 'email'),
                }],
                ['Advance', {
                    'classes': ('collapse',),  # CSS 显示或者隐藏age
                    'fields': ('age',),
                }]
            )

# Register your models here.
admin.site.register(Contact,ContactAdmin)
admin.site.register([Test])
