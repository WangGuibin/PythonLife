from  django.http import HttpResponse
from  django.shortcuts import render

def hello(req):
        context = {}
        context['hello'] = "hello world I love you My Python!!! Django"
        return render(req,'hello.html',context)