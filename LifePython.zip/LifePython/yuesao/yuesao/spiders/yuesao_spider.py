import scrapy
import re
import json


class YuesaoSpider(scrapy.Spider):
    name = 'yuesao'
    allow_domains = ['www.cgw.gr/news.htm']

    def start_requests(self):
        url = 'https://www.cgw.gr/news.htm'
        yield scrapy.Request(url)

    def parse(self, response):
            html = response.text  # 获取网页源代码
            reg = '<li><span>(.*?)</span><a href="(.*?)">(.*?)</a></li>'
            items = []
            infos = re.findall(reg, html)
            for time,url,title in infos:
                        item = {}
                        item["title"] = title
                        item["link"] = "https://www.cgw.gr"+url
                        item["date"] = time
                        items.append(item)
            with open('items.json','w') as f:
                        # 写入用dump或dumps  读取用loads  中文处理ensure_ascii=False 缩进indent=4
                        json.dump(items,f,ensure_ascii=False,indent=4)






