from pyquery import PyQuery as pq

# doc = pq(filename='testQuery.html')
# print(doc.html())
# print(type(doc))
# print(doc('ul').text())
# print(doc('li').text())

p = pq('<p id="hello" class="world"></p>')('p')
# print(p.attr('id'))
# print(p.attr('class','世界'))


