from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait

#打开访问浏览器
# browser = webdriver.Chrome()
# browser.get('http://www.baidu.com')
# browser.maximize_window()
# print(browser.page_source)

# 查找单个元素 三种方式查找返回同一个结果
# browser = webdriver.Chrome()
# browser.get('https://www.taobao.com')
# input_first = browser.find_element_by_id('q')
# input_second = browser.find_element_by_css_selector('#q')
# input_third = browser.find_element_by_xpath('//*[@id="q"]')
# print(input_first, input_second, input_third)
# browser.close()


# 根据属性查找元素
# browser = webdriver.Chrome()
# browser.get('https://www.taobao.com')
# input_first = browser.find_element(By.ID, 'q')
# print(input_first)
# browser.close()


# 查找多个元素
# browser = webdriver.Chrome()
# browser.get('https://www.taobao.com')
# lis = browser.find_elements_by_css_selector('.service-bd li')
# print(lis)
# browser.close()

# 模仿浏览器点击
# browser = webdriver.Chrome()
# browser.get('https://www.taobao.com')
# # input = browser.find_element_by_id('q')
# # input.send_keys('娃娃')
# # time.sleep(1)
# # input.clear()
# # input.send_keys('iPad')
# # button = browser.find_element_by_class_name('btn-search')
# # button.click()
#
# button = browser.find_element_by_xpath('//ul[@class="nav-bd"]/li[2]')
# button.click()
# time.sleep(1)
#
# button = browser.find_element_by_xpath('//ul[@class="nav-bd"]/li[3]')
# button.click()
# time.sleep(1)
#
# button = browser.find_element_by_xpath('//ul[@class="nav-bd"]/li[4]')
# button.click()
# time.sleep(1)
#
# button = browser.find_element_by_xpath('//ul[@class="nav-bd"]/li[5]')
# button.click()
# time.sleep(1)

# 动作链
# browser = webdriver.Chrome()
# url = 'http://www.runoob.com/try/try.php?filename=jqueryui-api-droppable'
# browser.get(url)
# browser.switch_to.frame('iframeResult')
# source = browser.find_element_by_css_selector('#draggable')
# target = browser.find_element_by_css_selector('#droppable')
# actions = ActionChains(browser)
# actions.drag_and_drop(source, target)
# actions.perform()

# 执行JS  滚动到最底部 并执行弹窗
# browser = webdriver.Chrome()
# browser.get('http://cuiqingcai.com')
# browser.execute_script('window.scrollTo(0, document.body.scrollHeight)')
# browser.execute_script('alert("到底了")')

# #前进后退
# browser = webdriver.Chrome()
# browser.get('https://www.baidu.com/')
# browser.get('https://www.taobao.com/')
# browser.get('https://www.jjys168.com/')
# browser.back() #后退
# time.sleep(1)
# browser.forward()#前进
# browser.close()

# # cookies
# browser = webdriver.Chrome()
# browser.get('https://www.zhihu.com/explore')
# print(browser.get_cookies())
# browser.add_cookie({'name': 'name', 'domain': 'www.zhihu.com', 'value': 'germey'})
# print(browser.get_cookies())
# browser.delete_all_cookies()
# print(browser.get_cookies())

# browser = webdriver.Chrome()
# browser.get('https://www.baidu.com')
# browser.execute_script('window.open()')
# print(browser.window_handles)
# browser.switch_to.window(browser.window_handles[1])
# browser.get('https://www.taobao.com')
# time.sleep(1)
# browser.execute_script('window.open()')
# browser.switch_to.window(browser.window_handles[2])
# browser.get('https://python.org')

# 拿双猴测试一下

# browser = webdriver.Chrome()
# browser.get('https://www.dosmono.com/')
# browser.execute_script('window.scrollTo(0, document.body.scrollHeight)')
# pro = browser.find_element_by_xpath('//div[@id="videoList"]/a[3]')
# url = pro.get_attribute('href')
# browser.execute_script('window.open()')
# browser.switch_to.window(browser.window_handles[1])
# browser.get(url)